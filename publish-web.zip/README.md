# Publish Web

Web app untuk upload HTML, ZIP, atau folder website lalu deploy ke Netlify.

## Fitur
- Pilih file HTML/aset, file ZIP, atau folder project
- Drag-and-drop
- Nama site bisa diatur
- Deploy menggunakan Netlify API
- Token disimpan di environment server, tidak di frontend
- Batas upload: 50 MB per file, maksimal 200 file

## Cara menjalankan
Butuh Node.js 18 atau lebih baru.

```bash
npm install
```

Set environment variable `NETLIFY_TOKEN` memakai Netlify Personal Access Token. Jangan masukkan token ke `public/` atau commit token ke Git.

Linux/macOS:
```bash
export NETLIFY_TOKEN="TOKEN_KAMU"
npm start
```

Windows PowerShell:
```powershell
$env:NETLIFY_TOKEN="TOKEN_KAMU"
npm start
```

Buka `http://localhost:3000`.

## Deploy aplikasi ini
Deploy project ini ke host yang mendukung Node.js (misalnya Render, Railway, atau VPS), lalu set `NETLIFY_TOKEN` di environment/secret settings host tersebut.

## Catatan
- Ini mem-publish website statis ke Netlify. Aplikasi backend dinamis seperti PHP, database, atau server Node milik project yang di-upload tidak ikut berjalan sebagai website statis.
- ZIP harus berisi `index.html` di root atau struktur folder yang sesuai.
- Untuk folder upload, browser mengirim path relatif. Pastikan `index.html` ada di root folder project, bukan hanya di subfolder.
- Kalau nama site sudah dipakai di Netlify, gunakan nama lain.
- Jangan bagikan token Netlify kepada siapa pun.
