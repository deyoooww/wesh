const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const path = require("path");
const fs = require("fs");
const os = require("os");

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024, files: 200 }
});
const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

function safeName(name) {
  return String(name || "my-website").toLowerCase()
    .replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-")
    .replace(/^-|-$/g, "").slice(0, 45) || "my-website";
}

app.get("/api/status", (_req, res) => {
  res.json({ ready: Boolean(process.env.NETLIFY_TOKEN) });
});

app.post("/api/publish", upload.array("files", 200), async (req, res) => {
  const token = process.env.NETLIFY_TOKEN;
  if (!token) return res.status(503).json({
    error: "NETLIFY_TOKEN belum dipasang di environment server."
  });
  if (!req.files || !req.files.length) return res.status(400).json({ error: "Pilih file dulu." });

  let zip;
  try {
    zip = new AdmZip();
    let added = 0;
    for (const file of req.files) {
      const original = (file.originalname || "index.html").replace(/\\/g, "/");
      const clean = original.split("/").filter(p => p && p !== "." && p !== "..").join("/");
      if (!clean) continue;
      if (path.extname(clean).toLowerCase() === ".zip") {
        const inner = new AdmZip(file.buffer);
        for (const entry of inner.getEntries()) {
          if (entry.isDirectory) continue;
          const entryName = entry.entryName.replace(/\\/g, "/");
          const parts = entryName.split("/");
          if (parts.some(p => p === "..")) continue;
          zip.addFile(entryName, entry.getData());
          added++;
        }
      } else {
        zip.addFile(clean, file.buffer);
        added++;
      }
    }
    if (!added) return res.status(400).json({ error: "File tidak valid atau ZIP kosong." });

    const entries = zip.getEntries().filter(e => !e.isDirectory);
    if (!entries.some(e => e.entryName.toLowerCase() === "index.html" || e.entryName.toLowerCase().endsWith("/index.html"))) {
      return res.status(400).json({ error: "File index.html tidak ditemukan. Pastikan index.html ada di root folder website." });
    }

    const siteName = safeName(req.body.siteName || "website-saya");
    const createResponse = await fetch("https://api.netlify.com/api/v1/sites", {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ name: siteName })
    });
    let site = await createResponse.json().catch(() => ({}));
    if (!createResponse.ok) {
      return res.status(createResponse.status).json({
        error: site.message || "Gagal membuat site. Coba nama lain atau cek token Netlify."
      });
    }

    const deployResponse = await fetch(`https://api.netlify.com/api/v1/sites/${site.id}/deploys`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/zip"
      },
      body: zip.toBuffer()
    });
    const deploy = await deployResponse.json().catch(() => ({}));
    if (!deployResponse.ok) {
      return res.status(deployResponse.status).json({
        error: deploy.message || "Site dibuat, tapi proses deploy gagal.",
        siteUrl: site.ssl_url || site.url
      });
    }
    res.json({
      success: true,
      url: deploy.ssl_url || deploy.deploy_ssl_url || site.ssl_url || site.url,
      siteUrl: site.ssl_url || site.url,
      deployState: deploy.state || "processing",
      message: "Upload berhasil dikirim. Tunggu sebentar sampai proses publish selesai."
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Terjadi kesalahan saat memproses file." });
  }
});

app.listen(PORT, () => console.log(`Publish Web berjalan di port ${PORT}`));
